# Import into Anki Desktop

1. Create a dedicated note type with nine fields, in this order: ID, Audio, Scene, Purpose, Hints, Script, Translation, Notes, Source. Keep ID as the first field. The tenth TSV column supplies tags.
2. Paste front.html, back.html and style.css into that note type's Front Template, Back Template and Styling. Use one card template.
3. Copy the **files inside media/** into Anki's collection.media folder. Keep filenames flat; do not copy the media folder itself or rename files.
4. Import notes.tsv as UTF-8/tab-delimited text, select that note type and your destination deck, enable HTML, and map the fields in the order above. The comment headers configure tab separation, HTML and tags on supported Anki versions; verify the preview. ID is a stable ordinary field, not an invented Anki GUID.
5. Preview a note and test audio before importing a large batch. Reimport using the same note type and first-field IDs to update rather than duplicate. Web progress and flip animations are not transferred. Anki's audio autoplay follows the user's Anki settings.

This export includes no personal review history. It is TSV + separate media, **not an .apkg**. Use Anki's own export after checking the imported deck if a packaged deck is needed; exclude scheduling/review history when sharing.

Official documentation: https://docs.ankiweb.net/importing/text-files.html
